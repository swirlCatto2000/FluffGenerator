A small character creator thing I made in the terminal for fun :) Supports naming and saving the characters you generate. Maybe I might do more with it in the near future. Added some funny tip of the day stuff because why not.

--------------------------
### Other Stuff

* Characters are saved to *savedCharacters* folder.
* All character accessories, tip of the day, etc is stored in *external data*.

-------------------------------------------
#### Commands

| Command   | Description                                                |
| --------- | ---------------------------------------------------------- |
| generate  | Generate a new character!                                  |
| exit      | Exit the Program.                                          |
| armed     | Want to give your character a new weapon loadout?          |
| neoMatrix | Green text effect just for fun haha.                       |
| saveLast  | Saves last character to the last created character folder. |

--------
